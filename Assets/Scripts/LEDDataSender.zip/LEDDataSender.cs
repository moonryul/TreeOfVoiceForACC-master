﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using System.Threading;
using UnityEngine.UI;

using System.IO.Ports;


public class LEDDataSender : MonoBehaviour
{

    //////////////////////////////////
    //
    // Private Variable
    //
    //////////////////////////////////
    SerialToArduinoMgr m_SerialToArduinoMgr; 
    Thread m_Thread;

    public byte[] m_LEDArray; // 200  LEDs
    float m_Delay;
    public const int m_LEDCount = 200; // m_LEDCount = 200

    //////////////////////////////////
    //
    // Function
    //
    //////////////////////////////////

  

    

    void Start()
    {
        // Serial Communication between C# and Arduino
        //http://www.hobbytronics.co.uk/arduino-serial-buffer-size = how to change the buffer size of arduino
        //https://www.codeproject.com/Articles/473828/Arduino-Csharp-and-Serial-Interface
        //Don't forget that the Arduino reboots every time you open the serial port from the computer - 
        //and the bootloader runs for a second or two gobbling up any serial data you send its way..
        //This takes a second or so, and during that time any data that you send is lost.
        //https://forum.arduino.cc/index.php?topic=459847.0

        m_SerialToArduinoMgr = new SerialToArduinoMgr();

        m_SerialToArduinoMgr.Setup();

        var port = m_SerialToArduinoMgr.port;

        m_LEDArray = new byte[m_LEDCount * 3]; // 280*3 = 840 < 1024

      
        // define an action
        Action updateArduino = () => {       

           port.Write(m_LEDArray, 0, m_LEDArray.Length); 
            // The WriteBufferSize of the Serial Port is 1024, whereas that of Arduino is 64
            //https://stackoverflow.com/questions/22768668/c-sharp-cant-read-full-buffer-from-serial-port-arduino

        };


        //m_Thread = null;
        //if(connected) { // create and start a thread for the action updateArduino
        m_Thread = new Thread(new ThreadStart(updateArduino)); // ThreadStart() is a delegate (pointer type)
        m_Thread.Start();

    }



    void Update()
    {

    }

}//public class LEDDataSender 


public class SerialToArduinoMgr
{

    //////////////////////////////////
    //
    // Private Variable
    //
    //////////////////////////////////

    SerialPort m_SerialPort;
    string m_PortName;

    [SerializeField] Text m_Text;

    //////////////////////////////////
    //
    // Property
    //
    //////////////////////////////////

    public bool connected { get { return m_PortName != null; } }
    public string portName { get { return m_PortName; } }
    public SerialPort port { get { return m_SerialPort; } }


  
    //////////////////////////////////
    //
    // Function
    //
    //////////////////////////////////

    public SerialToArduinoMgr() {
        bool active = Setup();
        SetArduinoToggle(active, m_PortName);

    }

    public bool Setup()
    {
        if (m_SerialPort != null)
        {
            if (m_SerialPort.IsOpen == true)
                return true;
            else
                m_PortName = null;
        }

        var portNames = SerialPort.GetPortNames();

        if (portNames.Length != 0)
        {
            m_PortName = portNames[0];
            m_SerialPort = new SerialPort(m_PortName, 115200); // bit rate= 567000 bps
            m_SerialPort.Open();



            // Deletage SerialDataReceivedEventHandler is a "pointer" to a method
            // It refers to the code itself, not the value of evaluating the code
  
            m_SerialPort.DataReceived += new SerialDataReceivedEventHandler(DataReceivedHandler);

            return true;
        }
        return false;
    }// bool Setup()

    public void SetArduinoToggle(bool active, string portName)
    {
        Color col = active ? new Color(1.0f, 1.0f, 1.0f, 1.0f) : new Color(1.0f, 1.0f, 1.0f, 0.3f);
        m_Text.color = col;
        var txt = active ? "Arduino(" + portName + ")" : "Arduino";
        m_Text.text = txt;
    }

   static void DataReceivedHandler(object sender, SerialDataReceivedEventArgs e)
    {

        SerialPort comport = (SerialPort) sender;
        byte[] temp = new byte[comport.ReadBufferSize];
        comport.Read(temp, 0, temp.Length);
        foreach (byte t in temp)
        {
            Debug.Log(t + ",");
        }
        
    }



}//public class ArduinoMgr 


