package com.yasirkula.unity;

/**
 * Created by yasirkula on 5.03.2018.
 */

public interface FileBrowserPermissionReceiver
{
	void OnPermissionResult( int result );
}
